# @deck-of-cards/standard-deck
Standard deck graphics for [deck.of.cards](https://deck.of.cards)

## Attributions
- [Suit icons](https://github.com/deck-of-cards/generate-cards/tree/master/fa) are from Font Awesome Pro, so notice it's [license](https://fontawesome.com/pro#pro-license-explained)!
- Royals modified from: https://commons.wikimedia.org/wiki/Category:SVG_English_pattern_playing_cards#/media/File:English_pattern_playing_cards_deck.svg

- Joker modified from: https://commons.wikimedia.org/wiki/File:Joker_black_02.svg

![Preview](preview.png)
